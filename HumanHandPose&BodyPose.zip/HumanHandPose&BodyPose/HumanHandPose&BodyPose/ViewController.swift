//
//  SceneDelegate.swift
//  HumanHandPose&BodyPose
//
//  Created by Chandana on 28/07/20.
//

import UIKit
import Vision

class ViewController: UIViewController, UINavigationControllerDelegate {
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var handSwitch: UISwitch!
    
    @IBOutlet weak var bodySwitch: UISwitch!
    
    var imageWidth: CGFloat = 0
    var imageHeight: CGFloat = 0
    var pathLayer: CALayer?
    
    
    lazy var handLandmarkRequest = VNDetectHumanHandPoseRequest(completionHandler: self.handleDetectedHandLandmarks)
    
    lazy var humanLandmarkRequest = VNDetectHumanBodyPoseRequest(completionHandler: self.handleDetectedHumanLandmarks)
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func selectPhotoAction(_ sender: Any) {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        self.present(imagePicker, animated: true)
    }
    
    func handleDetectedHandLandmarks(request: VNRequest?, error: Error?) {
        if let nsError = error as NSError? {
            print("Landmark Detection Error \(nsError)")
            return
        }
        // Perform drawing on the main thread.
        DispatchQueue.main.async {
            guard let drawLayer = self.pathLayer,
                  let results = request?.results as? [VNRecognizedPointsObservation] else {
                return
            }
            self.drawFeaturesforHandPose(onHands: results, onImageWithBounds: drawLayer.bounds)
            drawLayer.setNeedsDisplay()
        }
    }
    
    func handleDetectedHumanLandmarks(request: VNRequest?, error: Error?) {
        
        if let nsError = error as NSError? {
            print("human Landmark Detection Error \(nsError)")
            return
        }
        // Perform drawing on the main thread.
        DispatchQueue.main.async {
            guard let drawLayer = self.pathLayer,
                  let results = request?.results as? [VNRecognizedPointsObservation] else {
                return
            }
            
            self.drawFeaturesforBodyPose(onHumans: results, onImageWithBounds: drawLayer.bounds)
            drawLayer.setNeedsDisplay()
        }
        
    }
    
    func performVisionRequestforLandmarks(image: CGImage, orientation: CGImagePropertyOrientation) {
        
        // Fetch desired requests based on switch status.
        let requests = createVisionRequests()
        // Create a request handler.
        let imageRequestHandler = VNImageRequestHandler(cgImage: image,
                                                        orientation: orientation,
                                                        options: [:])
        
        // Send the requests to the request handler.
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                try imageRequestHandler.perform(requests)
            } catch let error as NSError {
                print("Failed to perform image request: \(error)")
                
                return
            }
        }
    }
    
    func createVisionRequests() -> [VNRequest] {
        
        var requests: [VNRequest] = []
        
        // Create & include a request if and only if switch is ON.
        if self.handSwitch.isOn {
            requests.append(self.handLandmarkRequest)
        }
        if self.bodySwitch.isOn {
            requests.append(self.humanLandmarkRequest)
        }
        
        // Return grouped requests as a single array.
        return requests
    }
    
    func show(_ image: UIImage) {
        
        // Remove previous paths & image
        pathLayer?.removeFromSuperlayer()
        pathLayer = nil
        imageView.image = nil
        
        // Account for image orientation by transforming view.
        let correctedImage = scaleAndOrient(image: image)
        
        // Place photo inside imageView.
        imageView.image = correctedImage
        
        // Transform image to fit screen.
        guard let cgImage = correctedImage.cgImage else {
            print("Trying to show an image not backed by CGImage!")
            return
        }
        
        let fullImageWidth = CGFloat(cgImage.width)
        let fullImageHeight = CGFloat(cgImage.height)
        
        let imageFrame = imageView.frame
        let widthRatio = fullImageWidth / imageFrame.width
        let heightRatio = fullImageHeight / imageFrame.height
        
        // ScaleAspectFit: The image will be scaled down according to the stricter dimension.
        let scaleDownRatio = max(widthRatio, heightRatio)
        
        // Cache image dimensions to reference when drawing CALayer paths.
        imageWidth = fullImageWidth / scaleDownRatio
        imageHeight = fullImageHeight / scaleDownRatio
        
        // Prepare pathLayer to hold Vision results.
        let xLayer = (imageFrame.width - imageWidth) / 2
        let yLayer = imageView.frame.minY + (imageFrame.height - imageHeight) / 2
        let drawingLayer = CALayer()
        drawingLayer.bounds = CGRect(x: xLayer, y: yLayer, width: imageWidth, height: imageHeight)
        drawingLayer.anchorPoint = CGPoint.zero
        drawingLayer.position = CGPoint(x: xLayer, y: yLayer)
        drawingLayer.opacity = 0.5
        pathLayer = drawingLayer
        self.view.layer.addSublayer(pathLayer!)
    }
    func scaleAndOrient(image: UIImage) -> UIImage {
        
        // Set a default value for limiting image size.
        let maxResolution: CGFloat = 640
        
        guard let cgImage = image.cgImage else {
            print("UIImage has no CGImage backing it!")
            return image
        }
        
        // Compute parameters for transform.
        let width = CGFloat(cgImage.width)
        let height = CGFloat(cgImage.height)
        var transform = CGAffineTransform.identity
        
        var bounds = CGRect(x: 0, y: 0, width: width, height: height)
        
        if width > maxResolution ||
            height > maxResolution {
            let ratio = width / height
            if width > height {
                bounds.size.width = maxResolution
                bounds.size.height = round(maxResolution / ratio)
            } else {
                bounds.size.width = round(maxResolution * ratio)
                bounds.size.height = maxResolution
            }
        }
        
        let scaleRatio = bounds.size.width / width
        let orientation = image.imageOrientation
        switch orientation {
        case .up:
            transform = .identity
        case .down:
            transform = CGAffineTransform(translationX: width, y: height).rotated(by: .pi)
        case .left:
            let boundsHeight = bounds.size.height
            bounds.size.height = bounds.size.width
            bounds.size.width = boundsHeight
            transform = CGAffineTransform(translationX: 0, y: width).rotated(by: 3.0 * .pi / 2.0)
        case .right:
            let boundsHeight = bounds.size.height
            bounds.size.height = bounds.size.width
            bounds.size.width = boundsHeight
            transform = CGAffineTransform(translationX: height, y: 0).rotated(by: .pi / 2.0)
        case .upMirrored:
            transform = CGAffineTransform(translationX: width, y: 0).scaledBy(x: -1, y: 1)
        case .downMirrored:
            transform = CGAffineTransform(translationX: 0, y: height).scaledBy(x: 1, y: -1)
        case .leftMirrored:
            let boundsHeight = bounds.size.height
            bounds.size.height = bounds.size.width
            bounds.size.width = boundsHeight
            transform = CGAffineTransform(translationX: height, y: width).scaledBy(x: -1, y: 1).rotated(by: 3.0 * .pi / 2.0)
        case .rightMirrored:
            let boundsHeight = bounds.size.height
            bounds.size.height = bounds.size.width
            bounds.size.width = boundsHeight
            transform = CGAffineTransform(scaleX: -1, y: 1).rotated(by: .pi / 2.0)
        default:
            transform = .identity
        }
        
        return UIGraphicsImageRenderer(size: bounds.size).image { rendererContext in
            let context = rendererContext.cgContext
            
            if orientation == .right || orientation == .left {
                context.scaleBy(x: -scaleRatio, y: scaleRatio)
                context.translateBy(x: -height, y: 0)
            } else {
                context.scaleBy(x: scaleRatio, y: -scaleRatio)
                context.translateBy(x: 0, y: -height)
            }
            context.concatenate(transform)
            context.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))
        }
    }
    
    func drawFeaturesforBodyPose(onHumans humans: [VNRecognizedPointsObservation], onImageWithBounds bounds: CGRect) {
        CATransaction.begin()
        for human in humans {
            let observationBox = self.humanBoundingBox(for: human)
            let humanBounds = boundingBox(forRegionOfInterest: observationBox, withinImageBounds: bounds)
            do {
                
                let allPoints = try human.recognizedPoints(forGroupKey: VNRecognizedPointGroupKey.all)
                
                var upperBodyPoints = [VNRecognizedPoint]()
                
                upperBodyPoints.append(allPoints[.bodyLandmarkKeyLeftWrist]!)
                upperBodyPoints.append(allPoints[.bodyLandmarkKeyLeftElbow]!)
                upperBodyPoints.append(allPoints[.bodyLandmarkKeyLeftShoulder]!)
                upperBodyPoints.append(allPoints[.bodyLandmarkKeyNeck]!)
                upperBodyPoints.append(allPoints[.bodyLandmarkKeyRightShoulder]!)
                upperBodyPoints.append(allPoints[.bodyLandmarkKeyRightElbow]!)
                upperBodyPoints.append(allPoints[.bodyLandmarkKeyRightWrist]!)
                
                var facePoints = [VNRecognizedPoint]()
                facePoints.append(allPoints[.bodyLandmarkKeyRightEar]!)
                facePoints.append(allPoints[.bodyLandmarkKeyRightEye]!)
                facePoints.append(allPoints[.bodyLandmarkKeyNose]!)
                facePoints.append(allPoints[.bodyLandmarkKeyLeftEye]!)
                facePoints.append(allPoints[.bodyLandmarkKeyLeftEar]!)
                
                var lowerBodyPoints = [VNRecognizedPoint]()
                lowerBodyPoints.append(allPoints[.bodyLandmarkKeyRightAnkle]!)
                lowerBodyPoints.append(allPoints[.bodyLandmarkKeyRightKnee]!)
                lowerBodyPoints.append(allPoints[.bodyLandmarkKeyRightHip]!)
                lowerBodyPoints.append(allPoints[.bodyLandmarkKeyRoot]!)
                lowerBodyPoints.append(allPoints[.bodyLandmarkKeyLeftHip]!)
                lowerBodyPoints.append(allPoints[.bodyLandmarkKeyLeftKnee]!)
                lowerBodyPoints.append(allPoints[.bodyLandmarkKeyLeftAnkle]!)
                
                var faceCGPoints = [CGPoint]()
                var lowerBodyCGPoints = [CGPoint]()
                var upperBodyCGPoints = [CGPoint]()
                
                for point in facePoints {
                    faceCGPoints.append(CGPoint(x: ((point.location.x) * bounds.width) + bounds.origin.x - humanBounds.origin.x, y: ((1 - (point.location.y)) * bounds.height) + bounds.origin.y - humanBounds.origin.y ))
                }
                
                for point in upperBodyPoints {
                    upperBodyCGPoints.append(CGPoint(x: ((point.location.x) * bounds.width) + bounds.origin.x - humanBounds.origin.x, y: ((1 - (point.location.y)) * bounds.height) + bounds.origin.y - humanBounds.origin.y ))
                }
                
                for point in lowerBodyPoints {
                    lowerBodyCGPoints.append(CGPoint(x: ((point.location.x) * bounds.width) + bounds.origin.x - humanBounds.origin.x, y: ((1 - (point.location.y)) * bounds.height) + bounds.origin.y - humanBounds.origin.y ))
                }
                
                var bodyLayers = [CAShapeLayer]()
                
                let faceLayer = CAShapeLayer()
                let facePath = CGMutablePath()
                facePath.move(to: faceCGPoints[0])
                for i in 1..<faceCGPoints.count {
                    facePath.addLine(to: faceCGPoints[i])
                }
                faceLayer.path = facePath
                bodyLayers.append(faceLayer)
                
                let upperBodyLayer = CAShapeLayer()
                let upperBodyPath = CGMutablePath()
                upperBodyPath.move(to: upperBodyCGPoints[0])
                for i in 1..<upperBodyCGPoints.count {
                    upperBodyPath.addLine(to: upperBodyCGPoints[i])
                }
                upperBodyLayer.path = upperBodyPath
                bodyLayers.append(upperBodyLayer)
                
                let lowerBodyLayer = CAShapeLayer()
                let lowerBodyPath = CGMutablePath()
                lowerBodyPath.move(to: lowerBodyCGPoints[0])
                for i in 1..<lowerBodyCGPoints.count {
                    lowerBodyPath.addLine(to: lowerBodyCGPoints[i])
                }
                lowerBodyLayer.path = lowerBodyPath
                bodyLayers.append(lowerBodyLayer)
                
                for index in 0..<3 {
                    
                    bodyLayers[index].lineWidth = 2
                    bodyLayers[index].strokeColor = UIColor.green.cgColor
                    bodyLayers[index].fillColor = nil
                    bodyLayers[index].shadowOpacity = 0.75
                    bodyLayers[index].shadowRadius = 4
                    
                    
                    bodyLayers[index].anchorPoint = .zero
                    bodyLayers[index].frame = humanBounds
                    bodyLayers[index].transform = CATransform3DMakeScale(1, 1, 1)
                    
                    pathLayer?.addSublayer(bodyLayers[index])
                }
            }
            
            catch  {
                print("error")
            }
        }
        
        CATransaction.commit()
    }
    
    func drawFeaturesforHandPose(onHands hands: [VNRecognizedPointsObservation], onImageWithBounds bounds: CGRect) {
        CATransaction.begin()
        for hand in hands {
            
            let observationBox = self.humanBoundingBox(for: hand)
            let humanBounds = boundingBox(forRegionOfInterest: observationBox, withinImageBounds: bounds)
            do {
                
                let allPoints = try hand.recognizedPoints(forGroupKey: VNRecognizedPointGroupKey.all)
                
                var indexPoints = [VNRecognizedPoint]()
                indexPoints.append(allPoints[.handLandmarkKeyIndexTIP]!)
                indexPoints.append(allPoints[.handLandmarkKeyIndexDIP]!)
                indexPoints.append(allPoints[.handLandmarkKeyIndexPIP]!)
                indexPoints.append(allPoints[.handLandmarkKeyIndexMCP]!)
                indexPoints.append(allPoints[.handLandmarkKeyWrist]!)
                
                var thumbPoints = [VNRecognizedPoint]()
                thumbPoints.append(allPoints[.handLandmarkKeyThumbTIP]!)
                thumbPoints.append(allPoints[.handLandmarkKeyThumbIP]!)
                thumbPoints.append(allPoints[.handLandmarkKeyThumbMP]!)
                thumbPoints.append(allPoints[.handLandmarkKeyThumbCMC]!)
                thumbPoints.append(allPoints[.handLandmarkKeyWrist]!)
                
                var ringFingerPoints = [VNRecognizedPoint]()
                ringFingerPoints.append(allPoints[.handLandmarkKeyRingTIP]!)
                ringFingerPoints.append(allPoints[.handLandmarkKeyRingDIP]!)
                ringFingerPoints.append(allPoints[.handLandmarkKeyRingPIP]!)
                ringFingerPoints.append(allPoints[.handLandmarkKeyRingMCP]!)
                ringFingerPoints.append(allPoints[.handLandmarkKeyWrist]!)
                
                var middleFingerPoints = [VNRecognizedPoint]()
                middleFingerPoints.append(allPoints[.handLandmarkKeyMiddleTIP]!)
                middleFingerPoints.append(allPoints[.handLandmarkKeyMiddleDIP]!)
                middleFingerPoints.append(allPoints[.handLandmarkKeyMiddlePIP]!)
                middleFingerPoints.append(allPoints[.handLandmarkKeyMiddleMCP]!)
                middleFingerPoints.append(allPoints[.handLandmarkKeyWrist]!)
                
                var littleFingerPoints = [VNRecognizedPoint]()
                littleFingerPoints.append(allPoints[.handLandmarkKeyLittleTIP]!)
                littleFingerPoints.append(allPoints[.handLandmarkKeyLittleDIP]!)
                littleFingerPoints.append(allPoints[.handLandmarkKeyLittlePIP]!)
                littleFingerPoints.append(allPoints[.handLandmarkKeyLittleMCP]!)
                littleFingerPoints.append(allPoints[.handLandmarkKeyWrist]!)
                
                
                var  indexCGPoints = [CGPoint]()
                var  middleCGPoints = [CGPoint]()
                var  littleCGPoints = [CGPoint]()
                var  thumbCGPoints = [CGPoint]()
                var  ringCGPoints = [CGPoint]()
                
                
                for point in indexPoints {
                    let reqPoint = CGPoint(x: (point.location.x), y: (point.location.y))
                    
                    indexCGPoints.append(CGPoint(x: (reqPoint.x * bounds.width) + bounds.origin.x - humanBounds.origin.x, y: ((1 - reqPoint.y) * bounds.height) + bounds.origin.y - humanBounds.origin.y ))
                }
                
                
                for point in middleFingerPoints {
                    let reqPoint = CGPoint(x: (point.location.x), y: (point.location.y))
                    
                    middleCGPoints.append(CGPoint(x: (reqPoint.x * bounds.width) + bounds.origin.x - humanBounds.origin.x, y: ((1 - reqPoint.y) * bounds.height) + bounds.origin.y - humanBounds.origin.y ))
                }
                
                for point in littleFingerPoints {
                    let reqPoint = CGPoint(x: (point.location.x), y: (point.location.y))
                    
                    littleCGPoints.append(CGPoint(x: (reqPoint.x * bounds.width) + bounds.origin.x - humanBounds.origin.x, y: ((1 - reqPoint.y) * bounds.height) + bounds.origin.y - humanBounds.origin.y ))
                }
                
                
                for point in thumbPoints {
                    let reqPoint = CGPoint(x: (point.location.x), y: (point.location.y))
                    
                    thumbCGPoints.append(CGPoint(x: (reqPoint.x * bounds.width) + bounds.origin.x - humanBounds.origin.x, y: ((1 - reqPoint.y) * bounds.height) + bounds.origin.y - humanBounds.origin.y ))
                }
                
                for point in ringFingerPoints {
                    let reqPoint = CGPoint(x: (point.location.x), y: (point.location.y))
                    
                    ringCGPoints.append(CGPoint(x: (reqPoint.x * bounds.width) + bounds.origin.x - humanBounds.origin.x, y: ((1 - reqPoint.y) * bounds.height) + bounds.origin.y - humanBounds.origin.y ))
                }
                
                var handLayers = [CAShapeLayer]()
                let thumbLayer = CAShapeLayer()
                let thumbPath = CGMutablePath()
                thumbPath.move(to: thumbCGPoints[0])
                for i in 1..<thumbCGPoints.count {
                    thumbPath.addLine(to: thumbCGPoints[i])
                }
                thumbLayer.path = thumbPath
                handLayers.append(thumbLayer)
                
                let littleFingerLayer = CAShapeLayer()
                let littleFingerPath = CGMutablePath()
                littleFingerPath.move(to: littleCGPoints[0])
                for i in 1..<littleCGPoints.count {
                    littleFingerPath.addLine(to: littleCGPoints[i])
                }
                littleFingerLayer.path = littleFingerPath
                handLayers.append(littleFingerLayer)
                
                let ringLayer = CAShapeLayer()
                let ringPath = CGMutablePath()
                ringPath.move(to: ringCGPoints[0])
                for i in 1..<ringCGPoints.count {
                    ringPath.addLine(to: ringCGPoints[i])
                }
                ringLayer.path = ringPath
                handLayers.append(ringLayer)
                
                let indexLayer = CAShapeLayer()
                let indexPath = CGMutablePath()
                indexPath.move(to: indexCGPoints[0])
                for i in 1..<indexCGPoints.count {
                    indexPath.addLine(to: indexCGPoints[i])
                }
                indexLayer.path = indexPath
                handLayers.append(indexLayer)
                
                let middleLayer = CAShapeLayer()
                let middlePath = CGMutablePath()
                middlePath.move(to: middleCGPoints[0])
                for i in 1..<middleCGPoints.count {
                    middlePath.addLine(to: middleCGPoints[i])
                }
                middleLayer.path = middlePath
                handLayers.append(middleLayer)
                
                for index in 0..<5 {
                    
                    handLayers[index].lineWidth = 2
                    handLayers[index].strokeColor = UIColor.green.cgColor
                    handLayers[index].fillColor = nil
                    handLayers[index].shadowOpacity = 0.75
                    handLayers[index].shadowRadius = 4
                    
                    
                    handLayers[index].anchorPoint = .zero
                    handLayers[index].frame = humanBounds
                    handLayers[index].transform = CATransform3DMakeScale(1, 1, 1)
                    
                    pathLayer?.addSublayer(handLayers[index])
                }
                
            }
            
            catch  {
                print("error")
            }
        }
        
        CATransaction.commit()
    }
    
    func boundingBox(forRegionOfInterest: CGRect, withinImageBounds bounds: CGRect) -> CGRect {
        
        let imageWidth = bounds.width
        let imageHeight = bounds.height
        
        // Begin with input rect.
        var rect = forRegionOfInterest
        
        // Reposition origin.
        rect.origin.x *= imageWidth
        rect.origin.x += bounds.origin.x
        rect.origin.y = (1 - rect.origin.y) * imageHeight + bounds.origin.y
        
        // Rescale normalized coordinates.
        rect.size.width *= imageWidth
        rect.size.height *= imageHeight
        
        return rect
    }
    
    
    func humanBoundingBox(for observation: VNRecognizedPointsObservation) -> CGRect {
        
        var box = CGRect.zero
        var normalizedBoundingBox = CGRect.null
        
        guard let points = try? observation.recognizedPoints(forGroupKey: .all) else {
            return box
        }
        for (_, point) in points {
            normalizedBoundingBox = normalizedBoundingBox.union(CGRect(origin: point.location, size: .zero))
        }
        if !normalizedBoundingBox.isNull {
            box = normalizedBoundingBox
        }
        return box
    }
}

extension ViewController: UIImagePickerControllerDelegate {
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        // Dismiss picker, returning to original root viewController.
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        // Extract chosen image.
        let originalImage: UIImage = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        
        // Display image on screen.
        show(originalImage)
        
        // Convert from UIImageOrientation to CGImagePropertyOrientation.
        let cgOrientation = CGImagePropertyOrientation(rawValue: UInt32(originalImage.imageOrientation.rawValue))
        
        // Fire off request based on URL of chosen photo.
        guard let cgImage = originalImage.cgImage else {
            return
        }
        
        performVisionRequestforLandmarks(image: cgImage,
                                         orientation: cgOrientation!)
        // Dismiss the picker to return to original view controller.
        dismiss(animated: true, completion: nil)
    }
}
